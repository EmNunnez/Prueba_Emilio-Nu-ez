package org.example

// REQUERIMIENTO 1:

open class Reserva(
    val id: Int,
    val nombreCliente: String,
    val cantidadNoches: Int
) {
    open fun obtenerDescripcion(): String {
        return "Reserva Base #$id - Cliente: $nombreCliente ($cantidadNoches noches)"
    }
}

// REQUERIMIENTO 3:

enum class TipoAlojamiento(val descripcion: String) {
    HABITACION("Habitación de Hotel"),
    CABANA("Cabaña de Campo"),
    DEPARTAMENTO("Departamento Ejecutivo")
}

// REQUERIMIENTO 2:

data class ReservaAlojamiento(
    val idReserva: Int,
    val nClienteReserva: String,
    val cNochesReserva: Int,
    val valorPorNoche: Double,
    val cantidadPersonas: Int,
    val tipoAlojamiento: TipoAlojamiento,
    val notasAdicionales: String? = null
) : Reserva(idReserva, nClienteReserva, cNochesReserva) {

    // REQUERIMIENTO 6:

    fun calcularValorTotal(): Double {
        return valorPorNoche * cantidadNoches
    }

    // REQUERIMIENTO 9:

    override fun obtenerDescripcion(): String {
        val desc = super.obtenerDescripcion()
        return "$desc | Tipo: ${tipoAlojamiento.descripcion} | Personas: $cantidadPersonas | Valor/Noche: $$valorPorNoche"
    }
}

// REQUERIMIENTO 4 Y 5:

class MantenedorReservas {
    private val reservas = mutableListOf<ReservaAlojamiento>()

    fun registrarReserva(reserva: ReservaAlojamiento): String {
        return when {
            reserva.id <= 0 -> "ERROR: El identificador debe ser mayor que cero."
            reserva.nombreCliente.isBlank() -> "ERROR: El nombre del cliente no puede estar vacío."
            reserva.cantidadNoches <= 0 -> "ERROR: La cantidad de noches debe ser mayor que cero."
            reserva.valorPorNoche <= 0 -> "ERROR: El valor por noche debe ser mayor que cero."
            reserva.cantidadPersonas <= 0 -> "ERROR: La cantidad de personas debe ser mayor que cero."
            reservas.any { it.id == reserva.id } -> "ERROR: Ya existe una reserva con el ID ${reserva.id}."
            else -> {
                reservas.add(reserva)
                "ÉXITO: Reserva #${reserva.id} a nombre de '${reserva.nombreCliente}' registrada correctamente."
            }
        }
    }

    fun obtenerReservas(): List<ReservaAlojamiento> {
        return reservas.toList()
    }
}

// REQUERIMIENTO 11:

fun consultarDisponibilidadAlojamiento() {
    println("Consultando disponibilidad de alojamientos en el sistema...")
    Thread.sleep(1000)
    println("¡Consulta completada! Alojamientos disponibles.\n")
}

// REQUERIMIENTO 10:

fun validarConversionMonto(): Double {
    println("=== CONTROL DE ERRORES (TRY-CATCH) ===")
    println("Validando conversión de entrada de texto a número...")
    val montoParsed: Double = try {
        "cuarenta mil".toDouble()
    } catch (e: NumberFormatException) {
        println("[ERROR CONTROLADO]: Falló la conversión de texto a número: ${e.message}")
        0.0
    }
    return montoParsed
}

// REQUERIMIENTO 12:

fun main() {
    consultarDisponibilidadAlojamiento()

    val mantenedor = MantenedorReservas()

    println("=== 1. REGISTRO DE RESERVAS ===")

    val reservasAProbar = listOf(
        ReservaAlojamiento(1, "Ana Pérez", 3, 45000.0, 2, TipoAlojamiento.HABITACION, "Frente al mar"),
        ReservaAlojamiento(2, "Carlos Gómez", 5, 80000.0, 4, TipoAlojamiento.CABANA),
        ReservaAlojamiento(3, "Laura Martínez", 2, 60000.0, 1, TipoAlojamiento.DEPARTAMENTO),
        ReservaAlojamiento(-1, "Pedro Soto", 2, 40000.0, 2, TipoAlojamiento.HABITACION),
        ReservaAlojamiento(4, "", 3, 50000.0, 2, TipoAlojamiento.CABANA),
        ReservaAlojamiento(5, "Juan Silva", 0, 30000.0, 2, TipoAlojamiento.HABITACION),
        ReservaAlojamiento(6, "Maria Rivas", 2, -10000.0, 2, TipoAlojamiento.HABITACION),
        ReservaAlojamiento(1, "Diego López", 4, 45000.0, 2, TipoAlojamiento.HABITACION)
    )

    for (reserva in reservasAProbar) {
        val resultado = mantenedor.registrarReserva(reserva)
        println(resultado)
    }

    println()
    validarConversionMonto()

    val listaReservas = mantenedor.obtenerReservas()

    // REQUERIMIENTO 8:

    println("\n=== 2. VISUALIZACIÓN DE RESERVAS REGISTRADAS ===")

    for (r in listaReservas) {
        val totalReserva = r.calcularValorTotal()
        val nota = if (r.notasAdicionales != null) " [Nota: ${r.notasAdicionales}]" else ""
        println("ID: ${r.id} | Cliente: ${r.nombreCliente} | Noches: ${r.cantidadNoches} | Valor/Noche: $${r.valorPorNoche} | Personas: ${r.cantidadPersonas} | Tipo: ${r.tipoAlojamiento.descripcion} | Total: $$totalReserva$nota")
        println("   └─ Desc: ${r.obtenerDescripcion()}")
    }

    // REQUERIMIENTO 6 Y 7:

    println("\n=== 3. CONSULTAS DE COLECCIONES Y CÁLCULO DE INVENTARIO ===")

    val recaudacionTotal = listaReservas.sumOf { it.calcularValorTotal() }
    println("Valor Total Recaudado por todas las reservas: $$recaudacionTotal")

    val reservasHabitacion = listaReservas.filter { it.tipoAlojamiento == TipoAlojamiento.HABITACION }
    println("Reservas de tipo Habitación: ${reservasHabitacion.map { it.nombreCliente }}")

    val nombresClientes = listaReservas.map { it.nombreCliente }
    println("Lista general de nombres de clientes: $nombresClientes")

    // REQUERIMIENTO 9:

    println("\n=== 4. DEMOSTRACIÓN DE POLIMORFISMO ===")

    val reservaGeneral: Reserva = ReservaAlojamiento(10, "Roberto Tapia", 4, 75000.0, 3, TipoAlojamiento.CABANA)
    println("Llamando al método 'obtenerDescripcion()' desde una variable de tipo 'Reserva':")
    println(reservaGeneral.obtenerDescripcion())
}