document.addEventListener('DOMContentLoaded', () => {
    cargarCarrito();
});

// Lee localStorage y dibuja los items en la vista
function cargarCarrito() {
    const contenedor = document.getElementById('lista-carrito');
    const subtotalEl = document.getElementById('cart-subtotal');
    const totalEl = document.getElementById('cart-total');

    if (!contenedor) return;

    let cart = [];
    try {
        cart = JSON.parse(localStorage.getItem('cart')) || [];
    } catch (e) {
        cart = [];
    }

    contenedor.innerHTML = '';

    if (!Array.isArray(cart) || cart.length === 0) {
        contenedor.innerHTML = `
            <div style="text-align: center; color: #94a3b8; padding: 25px 0;">
                <p style="font-size: 1.1rem; margin-bottom: 10px;">Tu carrito está vacío 🛒</p>
                <a href="index.html" style="color: #38bdf8; text-decoration: underline; font-size: 0.95rem;">Ir a la tienda</a>
            </div>
        `;
        if (subtotalEl) subtotalEl.textContent = '$0';
        if (totalEl) totalEl.textContent = '$3.990';
        if (typeof actualizarContadorCarrito === 'function') actualizarContadorCarrito();
        return;
    }

    let subtotal = 0;

    cart.forEach((item, index) => {
        const cantidad = Number(item.cantidad) || 1;
        const precio = Number(item.precio) || 0;
        const totalProducto = precio * cantidad;
        subtotal += totalProducto;

        const itemDiv = document.createElement('div');
        itemDiv.style.cssText = 'display: flex; align-items: center; justify-content: space-between; background: #0f172a; padding: 12px; border-radius: 6px; border: 1px solid #334155; gap: 15px;';

        itemDiv.innerHTML = `
            <div style="display: flex; align-items: center; gap: 12px; flex: 1;">
                <img src="${item.imagen || 'https://via.placeholder.com/60'}" alt="${item.nombre}" style="width: 50px; height: 50px; object-fit: cover; border-radius: 4px;">
                <div>
                    <h4 style="color: #f8fafc; font-size: 0.95rem; margin: 0 0 4px 0;">${item.nombre}</h4>
                    <span style="color: #38bdf8; font-weight: bold; font-size: 0.9rem;">$${precio.toLocaleString('es-CL')}</span>
                </div>
            </div>

            <div style="display: flex; align-items: center; gap: 8px;">
                <button onclick="cambiarCantidad(${index}, -1)" style="background: #334155; color: #fff; border: none; width: 26px; height: 26px; border-radius: 4px; cursor: pointer; font-weight: bold;">-</button>
                <span style="color: #fff; font-weight: bold; min-width: 20px; text-align: center;">${cantidad}</span>
                <button onclick="cambiarCantidad(${index}, 1)" style="background: #334155; color: #fff; border: none; width: 26px; height: 26px; border-radius: 4px; cursor: pointer; font-weight: bold;">+</button>
            </div>

            <div style="text-align: right; min-width: 90px;">
                <div style="color: #f8fafc; font-weight: bold; font-size: 0.95rem;">$${totalProducto.toLocaleString('es-CL')}</div>
                <button onclick="eliminarDelCarrito(${index})" style="background: none; border: none; color: #ef4444; cursor: pointer; font-size: 0.8rem; margin-top: 4px; padding: 0;">Eliminar</button>
            </div>
        `;

        contenedor.appendChild(itemDiv);
    });

    const costoEnvio = 3990;
    const total = subtotal + costoEnvio;

    if (subtotalEl) subtotalEl.textContent = `$${subtotal.toLocaleString('es-CL')}`;
    if (totalEl) totalEl.textContent = `$${total.toLocaleString('es-CL')}`;

    if (typeof actualizarContadorCarrito === 'function') actualizarContadorCarrito();
}

// Cambiar cantidad (+1 / -1)
function cambiarCantidad(index, cambio) {
    let cart = JSON.parse(localStorage.getItem('cart')) || [];
    if (!cart[index]) return;

    cart[index].cantidad = (Number(cart[index].cantidad) || 1) + cambio;

    if (cart[index].cantidad <= 0) {
        cart.splice(index, 1);
    }

    localStorage.setItem('cart', JSON.stringify(cart));
    cargarCarrito();
}

// Eliminar un producto
function eliminarDelCarrito(index) {
    let cart = JSON.parse(localStorage.getItem('cart')) || [];
    if (!cart[index]) return;

    cart.splice(index, 1);
    localStorage.setItem('cart', JSON.stringify(cart));
    cargarCarrito();
}

// Procesar el pago simulado
function procesarPago() {
    let cart = JSON.parse(localStorage.getItem('cart')) || [];

    if (!Array.isArray(cart) || cart.length === 0) {
        alert('Tu carrito está vacío. Agrega productos antes de pagar.');
        return;
    }

    const direccion = document.getElementById('ship-address')?.value.trim();
    const ciudad = document.getElementById('ship-city')?.value.trim();
    const telefono = document.getElementById('ship-phone')?.value.trim();

    if (!direccion || !ciudad || !telefono) {
        alert('Por favor completa todos los datos de envío requeridos (*).');
        return;
    }

    alert('¡Pedido realizado con éxito! Gracias por tu compra en TechGaming.');
    localStorage.removeItem('cart');
    window.location.href = 'index.html';
}