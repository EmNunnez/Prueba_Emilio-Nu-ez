document.addEventListener('DOMContentLoaded', () => {
    actualizarContadorCarrito();
});

// Listener global para sincronizar cambios entre pestañas y páginas
window.addEventListener('storage', (e) => {
    if (e.key === 'cart') {
        actualizarContadorCarrito();
        if (typeof cargarCarrito === 'function') {
            cargarCarrito();
        }
    }
});

// Sincroniza la burbuja/badge 🛒 Carrito (N)
function actualizarContadorCarrito() {
    const cartCountElements = document.querySelectorAll('#cart-count, .cart-count');
    if (!cartCountElements.length) return;

    let cart = [];
    try {
        cart = JSON.parse(localStorage.getItem('cart')) || [];
    } catch (e) {
        cart = [];
    }

    const totalItems = Array.isArray(cart) 
        ? cart.reduce((acc, item) => acc + (Number(item.cantidad) || 0), 0) 
        : 0;

    cartCountElements.forEach(el => {
        el.textContent = totalItems;
    });
}

// Función maestra para guardar un producto de forma segura
function agregarAlCarrito(id, nombre, precio, imagen, cantidad = 1) {
    let cart = [];
    try {
        cart = JSON.parse(localStorage.getItem('cart')) || [];
    } catch (e) {
        cart = [];
    }

    if (!Array.isArray(cart)) cart = [];

    // Limpia el precio si viene como texto (ej: "$49.990" -> 49990)
    const precioNumerico = typeof precio === 'string' 
        ? parseInt(precio.replace(/[^0-9]/g, ''), 10) 
        : Number(precio);

    const cantNumerica = Number(cantidad) || 1;

    // Comprobar si el producto ya existe por id o por nombre
    const itemExistente = cart.find(item => String(item.id) === String(id) || item.nombre === nombre);

    if (itemExistente) {
        itemExistente.cantidad = Number(itemExistente.cantidad) + cantNumerica;
    } else {
        cart.push({
            id: String(id || Date.now()),
            nombre: nombre,
            precio: precioNumerico || 0,
            imagen: imagen || 'https://via.placeholder.com/150',
            cantidad: cantNumerica
        });
    }

    localStorage.setItem('cart', JSON.stringify(cart));
    actualizarContadorCarrito();
}

// Vaciar carrito
function vaciarCarrito() {
    let cart = [];
    try {
        cart = JSON.parse(localStorage.getItem('cart')) || [];
    } catch (e) {
        cart = [];
    }

    if (!Array.isArray(cart) || cart.length === 0) return;

    if (confirm('¿Estás seguro de que deseas vaciar el carrito?')) {
        localStorage.removeItem('cart');
        actualizarContadorCarrito();
        
        if (typeof cargarCarrito === 'function') {
            cargarCarrito();
        }
    }
}